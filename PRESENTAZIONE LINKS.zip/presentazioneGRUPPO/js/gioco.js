var canvas = document.getElementById("gameCanvas");
    var ctx = canvas.getContext("2d");

    var birdImg = document.getElementById("birdImg");
    var pipeImgTop = document.getElementById("pipeImgTop");
    var pipeImgBottom = document.getElementById("pipeImgBottom");
    var explosionImg = document.getElementById("explosionImg");

    var bird = {
        x: 50,
        y: canvas.height / 2,
        radius: 20,
        velocity: 0,
        gravity: 0.6,
        jumpStrength: -7,
        getTop: function() {
            return this.y - this.radius;
        },
        getBottom: function() {
            return this.y + this.radius;
        },
        getLeft: function() {
            return this.x - this.radius;
        },
        getRight: function() {
            return this.x + this.radius;
        }
    };

    var pipes = [];

    var gap = 120;
    var pipeWidth = 50;
    var pipeMargin = 150;
    var pipeSpeed = 3;
    var score = 0;

    var isGameOver = false;

    function drawBird() {
        ctx.drawImage(birdImg, bird.x - bird.radius, bird.y - bird.radius, bird.radius * 2, bird.radius * 2);
    }

    function drawPipe(pipeX, pipeY, pipeHeight, isTop) {
        if (isTop) {
            ctx.drawImage(pipeImgTop, pipeX, pipeY, pipeWidth, pipeHeight);
        } else {
            ctx.drawImage(pipeImgBottom, pipeX, pipeY, pipeWidth, pipeHeight);
        }
    }
    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Draw bird
        drawBird();

        // Draw pipes
        for (var i = 0; i < pipes.length; i++) {
            drawPipe(pipes[i].x, 0, pipes[i].top, true);
            drawPipe(pipes[i].x, canvas.height - pipes[i].bottom, pipes[i].bottom, false);
        }

        // Display score
        ctx.font = "24px Arial";
        ctx.fillStyle = "white";
        ctx.fillText("Score: " + score, 20, 30);

        // If game over, show explosion
        if (isGameOver) {
            ctx.drawImage(explosionImg, bird.x - bird.radius, bird.y - bird.radius, bird.radius * 2, bird.radius * 2);
        }
    }

    function update() {
        if (isGameOver) return;

        bird.velocity += bird.gravity;
        bird.y += bird.velocity;

        if (bird.y > canvas.height - bird.radius) {
            bird.y = canvas.height - bird.radius;
            bird.velocity = 0;
        }

        // Generate pipes
        if (pipes.length === 0 || pipes[pipes.length - 1].x < canvas.width - pipeMargin) {
            var topHeight = Math.floor(Math.random() * (canvas.height - gap - pipeMargin)) + pipeMargin;
            var bottomHeight = canvas.height - gap - topHeight;
            pipes.push({ x: canvas.width, top: topHeight, bottom: bottomHeight, passed: false });
        }

        // Move pipes
        for (var i = 0; i < pipes.length; i++) {
            pipes[i].x -= pipeSpeed;

            // Check collision
            if (bird.getRight() > pipes[i].x && bird.getLeft() < pipes[i].x + pipeWidth &&
                (bird.getTop() < pipes[i].top || bird.getBottom() > canvas.height - pipes[i].bottom)) {
                gameOver();
            }

            // Check if passed through the pipe
            if (bird.x === pipes[i].x + pipeWidth && !pipes[i].passed) {
                score++;
                pipes[i].passed = true;
            }

            // Remove pipes that are out of the canvas
            if (pipes[i].x + pipeWidth < 0) {
                pipes.splice(i, 1);
                i--;
            }

            switch(score){
                case 1:increaseSpeed();
                case 2:increaseSpeed();
                case 3:increaseSpeed();
                case 4:increaseSpeed();
            }
        }
    }

    function gameOver() {
            isGameOver = true;
            restartButton.style.display = "block"; // Mostra il pulsante di restart
            restartButton.addEventListener("click", restartGame); // Aggiungi un evento click per riavviare il gioco
    }
    function restartGame() {
        isGameOver = false;
        restartButton.style.display = "none"; // Nascondi il pulsante di restart
        reset();
    }

    function reset() {
        bird.y = canvas.height / 2;
        pipes = [];
        score = 0;
    }
    var updateFrame=60
    function increaseSpeed(){
        updateFrame=updateFrame+1000; 
    }

    document.addEventListener("keydown", function (event) {
        if (event.keyCode === 77) { // Space key
            if (!isGameOver) {
                bird.velocity = bird.jumpStrength;
            }
        }
    });


    setInterval(function () {
        update();
        draw();
    }, 1000 / updateFrame);